"# Project Coke" 
"# My project's README" 
